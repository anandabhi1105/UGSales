// import axios from 'axios';

// const api = axios.create({
//   baseURL: 'http://localhost:5285/api',
// });

// export const getSalesReps = () => api.get('/salesreps');
// export const getSalesRep = (id) => api.get(`/salesreps/${id}`);
// export const createSalesRep = (data) => api.post('/salesreps', data);
// export const updateSalesRep = (id, data) => api.put(`/salesreps/${id}`, data);
// export const deleteSalesRep = (id) => api.delete(`/salesreps/${id}`);
// export const getSales = (params) => api.get('/sales', { params });


import axios from "axios";

const api = axios.create({
  baseURL: "https://localhost:5285/api",
  header: {
    "Content-Type": "application/json",
  },
});

export const loginUser = async (username, password) => {
  try {
    const response = await api.post("/api/auth/authentication", {
      username,
      password,
    });
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || "Login failed");
  }
};

export const registerUser = async (
  username,
  email,
  password,
  role = "User",
  phoneno
) => {
  try {
    const response = await api.post("/api/auth/register", {
      username,
      email,
      password,
      role,
      phoneno,
    });
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || "Login failed");
  }
};

export const setAuthToken = (token) => {
  if (token) {
    api.defaults.headers.common["Authorization"] = `Bearer ${token}`;
  } else {
    delete api.defaults.headers.common["Authorization"];
  }
};

export const getSalesReps = async () => {
  try {
    const response = await api.get('/salesreps');
    return response.data;
  } catch (error) {
    throw new Error(
      error.response?.data?.message || "Failed to fetch user data"
    );
  }
};

export const getSalesRep = async (id, token) => {
  try {
    const response = await api.get(`/salesreps/${id}`);
    return response.data;
  } catch (error) {
    throw new Error(
      error.response?.data?.message || "Failed to fetch user data"
    );
  }
};

export const updateSalesRep = async (id, data, token) => {
  try {
    const response = await api.put(`/salesreps/${id}`, data, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });
    return response.data;
  } catch (error) {
    throw new Error(
      error.response?.data?.message || "Failed to fetch user data"
    );
  }
};

export const createSalesRep = async (data, token) => {
  try {
    const response = await api.post('/salesreps', data, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });
    return response.data;
  } catch (error) {
    console.error("Error creating employee:", error);
    throw error;
  }
};

export const deleteSalesRep = async (id, token) => {
  try {
    const response = await api.delete(`/salesreps/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });
    return response.data;
  } catch (error) {
    console.error("Failed to delete employee:", error);
    throw error;
  }
};

export const getSales = async (params, token) => {
  try {
    const response = await api.get('/sales', { params }, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });
    return response.data;
  } catch (error) {
    console.error("Failed to delete employee:", error);
    throw error;
  }
};

export default api;