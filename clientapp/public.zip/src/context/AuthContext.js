import React, { createContext } from "react";

const AuthContext = createContext();

export default AuthContext;