import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate, useParams } from 'react-router-dom';
import { createSalesRep, getSalesRep, updateSalesRep } from '../services/api';

const SalesRepForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(id);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm();

  useEffect(() => {
    if (isEdit) {
      getSalesRep(id).then(res => {
        reset(res.data);
      });
    }
  }, [id, isEdit, reset]);

  const onSubmit = async (data) => {
    if (isEdit) {
      await updateSalesRep(id, data);
    } else {
      await createSalesRep(data);
    }
    navigate('/salesreps');
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 max-w-md mx-auto">
      <input {...register('firstName', { required: true })} placeholder="First Name" className="w-full border p-2" />
      {errors.firstName && <p className="text-red-500 text-sm">First name is required</p>}

      <input {...register('lastName', { required: true })} placeholder="Last Name" className="w-full border p-2" />
      {errors.lastName && <p className="text-red-500 text-sm">Last name is required</p>}

      <input {...register('email', { required: true })} type="email" placeholder="Email" className="w-full border p-2" />
      {errors.email && <p className="text-red-500 text-sm">Valid email is required</p>}

      <input {...register('phone', { required: true })} placeholder="Phone" className="w-full border p-2" />
      {errors.phone && <p className="text-red-500 text-sm">Phone is required</p>}

      <input {...register('region', { required: true })} placeholder="Region" className="w-full border p-2" />
      {errors.region && <p className="text-red-500 text-sm">Region is required</p>}

      <input {...register('platform', { required: true })} placeholder="Platform" className="w-full border p-2" />
      {errors.platform && <p className="text-red-500 text-sm">Platform is required</p>}

      <button type="submit" className="bg-green-500 text-white px-4 py-2 rounded">
        {isEdit ? 'Update' : 'Create'} Sales Rep
      </button>
    </form>
  );
}

export default SalesRepForm;