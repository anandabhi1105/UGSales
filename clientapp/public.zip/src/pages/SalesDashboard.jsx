import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { getSales } from '../services/api';

const SalesDashboard = () => {
  const [filters, setFilters] = useState({ product: '', region: '', platform: '' });
  const [sales, setSales] = useState([]);

  const loadSales = async () => {
    try {
      const res = await getSales(filters);
      setSales(res.data);
    } catch (error) {
      console.error('Error loading sales:', error);
    }
  };

  useEffect(() => {
    loadSales();
  }, [filters]);

  const handleChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const columns = [
    {
      name: 'Product',
      selector: (row) => row.product,
      sortable: true,
    },
    {
      name: 'Amount',
      selector: (row) => `$${row.amount.toFixed(2)}`,
      sortable: true,
    },
    {
      name: 'Sale Date',
      selector: (row) => new Date(row.saleDate).toLocaleDateString(),
      sortable: true,
    },
    {
      name: 'Sales Rep',
      selector: (row) => row.salesRepName,
      sortable: true,
    },
    {
      name: 'Region',
      selector: (row) => row.region,
      sortable: true,
    },
    {
      name: 'Platform',
      selector: (row) => row.platform,
      sortable: true,
    },
  ];

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold text-blue-700 mb-6">📊 UG Sales Dashboard</h2>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 bg-white p-4 rounded-lg shadow">
          <input
            name="product"
            value={filters.product}
            onChange={handleChange}
            placeholder="Filter by Product"
            className="border border-gray-300 rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
          />
          <input
            name="region"
            value={filters.region}
            onChange={handleChange}
            placeholder="Filter by Region"
            className="border border-gray-300 rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
          />
          <input
            name="platform"
            value={filters.platform}
            onChange={handleChange}
            placeholder="Filter by Platform"
            className="border border-gray-300 rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
          />
        </div>

        {/* Data Table */}
        <div className="bg-white rounded-lg shadow">
          <DataTable
            columns={columns}
            data={sales}
            pagination
            highlightOnHover
            striped
            responsive
            noDataComponent="No sales data available."
          />
        </div>
      </div>
    </div>
  );
}

export default SalesDashboard;
